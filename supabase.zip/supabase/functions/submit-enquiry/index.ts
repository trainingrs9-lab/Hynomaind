import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS' };
Deno.serve(async(req)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  if(req.method!=='POST')return new Response('Method not allowed',{status:405,headers:cors});
  try{
    const body=await req.json();
    const name=String(body.name||'').trim(),phone=String(body.phone||'').trim(),email=String(body.email||'').trim(),interest=String(body.interest||'').trim(),message=String(body.message||'').trim();
    if(!name||!phone||!interest||name.length>120||phone.length>40||email.length>254||message.length>3000) return new Response(JSON.stringify({error:'Please check the required fields.'}),{status:400,headers:{...cors,'Content-Type':'application/json'}});
    const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const {data,error}=await supabase.from('enquiries').insert({name,phone,email:email||null,interest,message:message||null}).select('id').single();
    if(error)throw error;
    const resendKey=Deno.env.get('RESEND_API_KEY');const notifyEmail=Deno.env.get('NOTIFY_EMAIL')||'trainingrs9@gmail.com';
    if(resendKey){
      const mail=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${resendKey}`,'Content-Type':'application/json'},body:JSON.stringify({from:Deno.env.get('EMAIL_FROM')||'HypnoMind Website <onboarding@resend.dev>',to:[notifyEmail],subject:`New HypnoMind enquiry: ${interest}`,text:`A new website enquiry has arrived.\n\nName: ${name}\nPhone: ${phone}\nEmail: ${email||'Not provided'}\nInterest: ${interest}\nMessage: ${message||'Not provided'}\nEnquiry ID: ${data.id}`})});
      if(!mail.ok)console.error('Email notification failed:',await mail.text());
    }else console.warn('RESEND_API_KEY not configured; enquiry saved without email notification.');
    return new Response(JSON.stringify({ok:true}),{status:200,headers:{...cors,'Content-Type':'application/json'}});
  }catch(error){console.error(error);return new Response(JSON.stringify({error:'Unable to submit enquiry.'}),{status:500,headers:{...cors,'Content-Type':'application/json'}});}
});
