-- Run this in Supabase SQL Editor.
create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  interest text not null,
  message text,
  status text not null default 'New' check (status in ('New','Contacted','Completed')),
  created_at timestamptz not null default now()
);
alter table public.enquiries enable row level security;
-- Only signed-in users whose app_metadata.role is admin can read/update enquiries.
create policy "Admins can read enquiries" on public.enquiries for select to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
create policy "Admins can update enquiries" on public.enquiries for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
-- No public insert policy: public submissions go through the Edge Function using server-side secrets.
